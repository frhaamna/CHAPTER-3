import java.util.Scanner;
public class Price {
    public static void main(String[] args) {
        
    String itemname;
    int colourcode;
    double price, quantity, totalprice, discount, discountrate = 0, priceafterdiscount;
    
  
   //Discount colour code display
   System.out.println("1. Pink (75%)");
   System.out.println("2. Purple (70%)");
   System.out.println("3. Blue (50%)");
   System.out.println("4. Green (30%)");
   System.out.println("5. Yellow (15%)");
   
   //User enter the colour code
   Scanner put = new Scanner(System.in);
    System.out.println("Please enter colour code :");
    colourcode = put.nextInt();
   
   switch (colourcode){
           
           //Setting discount rate 
           case 1 : discountrate = 75;
           break;
           
           case 2 : discountrate = 70;
           break;
           
           case 3 : discountrate = 50;
           break;
           
           case 4 : discountrate = 30;
           break;
           
           case 5 : discountrate = 15;
           break;
   }
           
   
   put.nextLine();
   
   //User enter the item name
   System.out.println("Please enter item name :");
   itemname =put.nextLine();
   
   //User enter the price
   System.out.println("Please enter the price :");
   price = put.nextDouble();
   
   //User enter the quantity
   System.out.println("Please enter the quantity :");
   quantity =put.nextDouble();
   
   //Calculate the price with the discount rate, quantity and totalprice
   totalprice = price*quantity;
   discount = totalprice * (discountrate/100);
   priceafterdiscount = totalprice - discount;
   
   //Display all the item name, price, quantity, total price, discount rate and price after discount
   System.out.println("Item name :"+itemname);
   System.out.println("Price : RM"+price);
   System.out.println("Quantity:"+quantity);
   System.out.println("Total Price :"+totalprice);
   System.out.println("Discount Rate :"+discountrate+"%");
   System.out.println("Price after Discount :"+priceafterdiscount);
   
   
   
    
    

    }
    
}
