import java.util.Scanner;
public class PurchaseSystem {
    public static void main(String[] args) {

    int candies;
    double price = 0, quantity, totalprice;
   
   //The menu display
   System.out.println("Welcome to Sweet Factory");
   System.out.println("1. Chocolate Bar       : RM 8");
   System.out.println("2. Lollipop            : RM 7");
   System.out.println("3. Dried Freeze Yogurt : RM 8");
   System.out.println("4. Chewing Gum         : RM 6");
   System.out.println("5. Sour Candy          : RM 5");
   
   Scanner put = new Scanner(System.in);
    System.out.println("Please enter candies :");
    candies = put.nextInt();
   
   switch (candies){
           //Setting the price
           case 1 : price = 8;
           break;
           
           case 2 : price = 7;
           break;
           
           case 3 : price = 8;
           break;
           
           case 4 : price = 6;
           break;
           
           case 5 : price = 5;
           break;
   }
           
   
   put.nextLine();
   
   //User enter the price
   System.out.println("Please enter the price :");
   price = put.nextDouble();
   
   //User enter the quantity of the item
   System.out.println("Please enter the quantity :");
   quantity =put.nextDouble();
   
   //Calculate price multiply with quantity
   totalprice = price*quantity;
   
   //Display all the candies, price, quantity, total price
   System.out.println("Candies :"+candies);
   System.out.println("Price : RM"+price);
   System.out.println("Quantity:"+quantity);
   System.out.println("Total Price :"+totalprice);

        
    }
    
}
