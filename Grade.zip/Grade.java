import java.util.Scanner;
public class Grade {

    public static void main(String[] args) {
        
        int mark;
        
        Scanner line= new Scanner(System.in);
        //User enter their marks
        System.out.println("Enter your final mark :");
        mark =line.nextInt();

        if(mark>=80){ //User enter their mark from 80 until 100
            System.out.println("Grade=A");}
                else if(mark>=70){ //User enter their marks from 70 until 79
            System.out.println("Grade=B");}
                else if(mark>=60){ //User enter their marks from 60 until 69
            System.out.println("Grade=C");}
                else if(mark>=40){ //User enter their marks from 40 until 59
            System.out.println("Grade=D");}
                else{ //User enter their marks from 0 until 39
            System.out.println("Grade=F");} //Display the grade
                }
        
        
    }
  


